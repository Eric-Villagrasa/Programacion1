#3

lista = []
numeros = []

var = input("Introduzca los valores: ")
lista = var.split("-")  

for item in lista:
    if item.isnumeric():  
        numeros.append(int(item))  

print(numeros)  
print(sum(numeros))  

print(numeros.set())
print(sum(numeros).set())