#1

nueva_lista = []
numeros = []
lista = input("Introduzca 6 números separados por guiones: ")

numeros = list(map(int, lista.split("-")))

print("Números ingresados:", numeros)

numeros.sort()

print("Máximo:", max(numeros))
print("Mínimo:", min(numeros))

promedio = sum(numeros) / len(numeros)

print("Promedio:", promedio)



